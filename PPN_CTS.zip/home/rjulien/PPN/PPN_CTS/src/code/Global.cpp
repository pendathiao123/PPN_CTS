#include "../headers/Global.h"
#include <curl/curl.h>
#include <nlohmann/json.hpp>
#include <iostream>
#include <fstream>
#include <vector>
#include <ctime>
#include <atomic>
#include <random>          
#include <thread>          
#include <chrono>          
#include <cmath>
#include <filesystem>

using json = nlohmann::json;

namespace Globals {
    std::mutex srdMutex;
    double lastSRDBTCValue = 0.0;

    std::mutex& getSRDMutex() {
        return srdMutex;
    }

    double getLastSRDBTCValue() {
        std::lock_guard<std::mutex> lock(srdMutex);
        return lastSRDBTCValue;
    }

    void setLastSRDBTCValue(double value) {
        std::lock_guard<std::mutex> lock(srdMutex);
        lastSRDBTCValue = value;
    }
}

std::atomic<bool> Global::stopRequested = false;

std::atomic<bool>& Global::getStopRequested() {
    return stopRequested;
}

// Callback pour la gestion de la réponse cURL
size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    ((std::string*)userp)->append((char*)contents, size * nmemb);
    return size * nmemb;
}

// Fonction pour récupérer la valeur actuelle du BTC depuis CoinGecko, puis applique un "bruit", une perturbation aléatoire entre 0 et 5%
void Global::generate_SRD_BTC_loop() {

    CURL* curl;
    CURLcode res;
    std::string readBuffer;

    std::default_random_engine generator(std::random_device{}());
    std::normal_distribution<double> distribution(0.05, 0.02);  // moyenne = 0.05, écart-type = 0.02

    while (!stopRequested) {
        readBuffer.clear();
        double currentBTCValue = -1;

        // 1. Initialiser cURL
        curl = curl_easy_init();
        if (curl) {
            curl_easy_setopt(curl, CURLOPT_URL, "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd");
            curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
            curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
            res = curl_easy_perform(curl);

            if (res == CURLE_OK) {
                try {
                    auto jsonData = json::parse(readBuffer);
                    if (jsonData.contains("bitcoin") && jsonData["bitcoin"].contains("usd")) {
                        currentBTCValue = jsonData["bitcoin"]["usd"];
                    }
                } catch (const std::exception& e) {
                    std::cerr << "Erreur parsing JSON : " << e.what() << std::endl;
                }
            } else {
                std::cerr << "Erreur cURL : " << curl_easy_strerror(res) << std::endl;
            }

            curl_easy_cleanup(curl);
        }

        if (currentBTCValue > 0) {
            // 2. Générer un facteur aléatoire (rd_filter)
            double rd_filter = std::clamp(distribution(generator), 0.0, 0.1); // borne entre 0 et 0.1

            // 3. Calculer SRD-BTC
            double srd_btc = (0.95 + rd_filter) * currentBTCValue;

            // 🔁 4. MAJ variable tampon (thread-safe)
            {
                ::Globals::setLastSRDBTCValue(srd_btc);
            }

            // 5. Timestamp (format lisible)
            time_t now = time(0);
            struct tm tstruct;
            char buf[80];
            tstruct = *localtime(&now);
            strftime(buf, sizeof(buf), "%Y-%m-%d %X", &tstruct);

            // 6. Écriture dans le fichier CSV
            std::ofstream file("/PPN/PPN_CTS/build/srd_btc_values.csv", std::ios::app);
            if (file.is_open()) {
                file << buf << "," << srd_btc << "\n";
                file.close();
                std::cout << "[LOG] SRD-BTC : " << srd_btc << " USD à " << buf << std::endl;
            } else {
                std::cerr << "Impossible d'écrire dans srd_btc_values.csv\n";
            }
        }

        // 7. Attente 2 secondes avant prochaine itération
        std::this_thread::sleep_for(std::chrono::seconds(2));
    }
}

double Global::getPrice(const std::string &currency)
{
    if (currency != "SRD-BTC")
        return 0.0;

    std::ifstream file("srd_btc_values.csv");
    if (!file.is_open())
    {
        std::cerr << "Impossible d'ouvrir le fichier srd_btc_values.csv" << std::endl;
        return 0.0;
    }

    std::string line;
    double closestValue = 0.0;
    double minTimeDiff = std::numeric_limits<double>::max();

    // Temps actuel
    std::time_t now = std::time(nullptr);

    while (std::getline(file, line))
    {
        std::stringstream ss(line);
        std::string timestampStr, valueStr;

        if (!std::getline(ss, timestampStr, ',') || !std::getline(ss, valueStr))
            continue;

        // Convertir timestampStr en time_t
        std::tm tm = {};
        std::istringstream tsStream(timestampStr);
        tsStream >> std::get_time(&tm, "%Y-%m-%d %H:%M:%S");
        if (tsStream.fail())
            continue;

        std::time_t entryTime = std::mktime(&tm);
        double diff = std::difftime(now, entryTime);
        if (diff < 0) diff = -diff;

        // Garder la valeur la plus proche du moment actuel
        if (diff < minTimeDiff)
        {
            minTimeDiff = diff;
            closestValue = std::stod(valueStr);
        }
    }

    file.close();
    return closestValue;
}

double Global::getPreviousPrice(const std::string &currency, int secondsBack)
{
    if (currency != "SRD-BTC")
        return 0.0;

    std::ifstream file("srd_btc_values.csv");
    if (!file.is_open())
    {
        std::cerr << "Impossible d'ouvrir le fichier srd_btc_values.csv" << std::endl;
        return 0.0;
    }

    std::string line;
    double closestValue = 0.0;
    double minTimeDiff = std::numeric_limits<double>::max();

    // Temps cible = maintenant - secondsBack
    std::time_t targetTime = std::time(nullptr) - secondsBack;

    while (std::getline(file, line))
    {
        std::stringstream ss(line);
        std::string timestampStr, valueStr;

        if (!std::getline(ss, timestampStr, ',') || !std::getline(ss, valueStr))
            continue;

        // Conversion du timestamp en time_t
        std::tm tm = {};
        std::istringstream tsStream(timestampStr);
        tsStream >> std::get_time(&tm, "%Y-%m-%d %H:%M:%S");
        if (tsStream.fail())
            continue;

        std::time_t entryTime = std::mktime(&tm);
        double diff = std::difftime(targetTime, entryTime);
        if (diff < 0) diff = -diff;

        // On garde la ligne la plus proche du temps visé
        if (diff < minTimeDiff)
        {
            minTimeDiff = diff;
            closestValue = std::stod(valueStr);
        }
    }

    file.close();
    return closestValue;
}
