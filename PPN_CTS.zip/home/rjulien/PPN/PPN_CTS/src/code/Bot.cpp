#include "../headers/Bot.h"
#include "../headers/Client.h"
#include "../headers/Global.h"
#include <iostream>
#include <unordered_map>
#include <ctime>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <limits>

Bot::Bot(const std::string &currency, const std::string &clientId) : client(std::make_shared<Client>()), global(std::make_shared<Global>()), id(clientId) {
    solde_origin = 10000.0f;
    prv_price = 0.0f;

    // Charger les soldes depuis le fichier portefeuille du client
    loadWallet();
}

Bot::~Bot() {
    // Sauvegarder les soldes dans le fichier portefeuille lors de la destruction du bot
    saveBalance();
}

void Bot::loadWallet() {
    // Charger le fichier portefeuille à partir du disque
    std::ifstream walletFile("../src/data/wallets/" + id + ".wallet");
    if (walletFile.is_open()) {
        std::string line;
        while (getline(walletFile, line)) {
            std::istringstream stream(line);
            std::string currency;
            double balance_value;
            if (std::getline(stream, currency, ':') && stream >> balance_value) {
                balance[currency] = balance_value;
            }
        }
        walletFile.close();
    } else {
        // Si le fichier n'existe pas (cas improbable ici vu qu'on le crée au début), on initialise les balances
        balance["DOLLARS"] = 10000.0;
        balance["SRD-BTC"] = 0.0;
    }
}

void Bot::saveBalance() {
    // Sauvegarder les balances en mémoire dans le fichier wallet
    std::ofstream walletFile("../src/data/wallets/" + id + ".wallet");
    if (walletFile.is_open()) {
        for (const auto& entry : balance) {
            walletFile << entry.first << ":" << entry.second << "\n";
        }
        walletFile.close();
    } else {
        std::cerr << "Erreur lors de l'ouverture du fichier portefeuille pour l'enregistrement." << std::endl;
    }
}

void Bot::trading(const std::string &currency) {
    double currentPrice = global->getPrice(currency);  // Utiliser l'instance global pour obtenir le prix actuel
    double previousPrice = global->getPreviousPrice(currency, 60);  // Utiliser l'instance global pour obtenir le prix précédent

    if (currentPrice > previousPrice) {
        // Si le prix a augmenté, acheter un certain pourcentage
        buyCrypto(currency, 0.1);  // Acheter 10% du solde en crypto
    } else if (currentPrice < previousPrice) {
        // Si le prix a diminué, vendre un certain pourcentage
        sellCrypto(currency, 0.1);  // Vendre 10% de la crypto
    } else {
        // Si le prix est stable, ne rien faire
        std::cout << "Aucun mouvement de prix détecté, pas d'action." << std::endl;
    }
}

void Bot::buyCrypto(const std::string &currency, double pourcentage) {
    std::cout << "Passage dans Bot::buyCrypto" << std::endl;
    if (!client->isConnected()) {
        client->StartClient("127.0.0.1", 4433, "7474", "77d7728205464e7791c58e510d613566874342c26413f970c45d7e2bc6dd9836");
    }

    double prix = global->getPrice(currency);  // ← ici on récupère le prix d'abord
    double amountInDollars = balance["DOLLARS"] * pourcentage;

    if (amountInDollars > balance["DOLLARS"]) {
        std::cerr << "Solde en dollars insuffisant pour achat." << std::endl;
        return;
    }

    balance["DOLLARS"] -= amountInDollars;
    balance[currency] += amountInDollars / prix;

    logTransaction("BUY", currency, pourcentage, amountInDollars, prix);

    client->buy(currency, pourcentage);
}


void Bot::sellCrypto(const std::string &currency, double pourcentage) {
    std::cout << "Passage dans Bot::sellCrypto" << std::endl;
    if (!client->isConnected()) {
        client->StartClient("127.0.0.1", 4433, "7474", "77d7728205464e7791c58e510d613566874342c26413f970c45d7e2bc6dd9836");
    }

    double prix = global->getPrice(currency);  // ← on récupère le prix avant
    double amountInCrypto = balance[currency] * pourcentage;

    if (amountInCrypto > balance[currency]) {
        std::cerr << "Solde en crypto insuffisant pour vente." << std::endl;
        return;
    }

    balance[currency] -= amountInCrypto;
    balance["DOLLARS"] += amountInCrypto * prix;

    logTransaction("SELL", currency, pourcentage, amountInCrypto, prix);

    client->sell(currency, pourcentage);
}


std::unordered_map<std::string, double> Bot::get_total_Balance() {
    return balance;
}

double Bot::getBalance(const std::string &currency) {
    if (balance.find(currency) != balance.end()) {
        return balance[currency];
    }
    return 0.0;
}

void Bot::updateBalance() {
    // Cette méthode peut être appelée si besoin de forcer la mise à jour des balances en mémoire
    // Par exemple, après un achat ou une vente
    saveBalance();
}

void Bot::logTransaction(const std::string& action, const std::string& currency, double percentage, double amount, double price) {
    std::ofstream logFile("../src/data/TransactionHistory.log", std::ios::app);
    if (logFile.is_open()) {
        auto now = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
        logFile << "[" << std::put_time(std::localtime(&now), "%F %T") << "] "
                << action << " | "
                << currency << " | "
                << "Pourcentage: " << percentage * 100 << "% | "
                << "Montant: " << amount << " | "
                << "Prix: " << price << " | "
                << "Solde USD: " << balance["DOLLARS"] << " | "
                << "Solde " << currency << ": " << balance[currency] << "\n";
        logFile.close();
    } else {
        std::cerr << "Impossible d'écrire dans TransactionHistory.log" << std::endl;
    }
}