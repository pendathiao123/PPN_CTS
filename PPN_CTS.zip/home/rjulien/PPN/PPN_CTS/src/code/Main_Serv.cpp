#include <iostream>
#include <filesystem>
#include "../headers/Server.h"
#include "../headers/Client.h"


int main() {

    // Vérifie si le répertoire des portefeuilles existe et le crée si ce n'est pas le cas
    std::filesystem::create_directories("../src/data/wallets");

    Server server;
    server.StartServer(4433, "../server.crt", "../server.key", "../configFile.csv","../log.csv");
    return 0;
}

