#include "../headers/Server.h"
#include "../headers/Bot.h"
#include "../headers/Client.h"
#include "../headers/Transaction.h"
#include "../headers/Global.h"
#include <openssl/hmac.h>
#include <openssl/evp.h>
#include <iomanip>
#include <iostream>
#include <random>
#include <sstream>
#include <openssl/rand.h>
#include <cstring>
#include <arpa/inet.h>
#include <unistd.h>
#include <fstream>
#include <unordered_map>
#include <ctime>
#include <chrono>
#include <thread>
#include <filesystem>
#include <memory>
#include <system_error>
#include <functional>

using namespace std;

// Implémentation de l'operator() pour le SSLDeleter
void SSLDeleter::operator()(SSL* ssl) const {
    if (ssl != nullptr) {
        SSL_free(ssl); // Libérer SSL
    }
}

// Implémentation de l'operator() pour le SSLCTXDeleter
void SSLCTXDeleter::operator()(SSL_CTX* ctx) const {
    if (ctx != nullptr) {
        SSL_CTX_free(ctx); // Libérer SSL_CTX
    }
}

string GenerateRandomString(size_t length) {
    static const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    string result;
    unsigned char rand_bytes[length];

    if (RAND_bytes(rand_bytes, length) != 1) {
        cerr << "Erreur de génération aléatoire" << endl;
        return "";
    }

    for (size_t i = 0; i < length; ++i) {
        result += charset[rand_bytes[i] % (sizeof(charset) - 1)];
    }

    return result;
}

string GenerateRandomId() {
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dis(1000, 9999);
    return to_string(dis(gen));
}

string GenerateToken() {
    string key = GenerateRandomString(32);
    string message = GenerateRandomString(16);

    unsigned char hash[EVP_MAX_MD_SIZE];
    unsigned int hash_len;

    HMAC(EVP_sha256(), key.c_str(), key.size(),
         reinterpret_cast<const unsigned char*>(message.c_str()), message.size(),
         hash, &hash_len);

    ostringstream oss;
    for (unsigned int i = 0; i < hash_len; ++i) {
        oss << hex << setw(2) << setfill('0') << (int)hash[i];
    }

    return oss.str();
}

unordered_map<string, string> LoadUsers(const string& filename) {
    unordered_map<string, string> users;
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Impossible d'ouvrir le fichier utilisateurs" << endl;
        return users;
    }

    string id, token;
    while (file >> id >> token) {
        users[id] = token;
    }
    return users;
}

void SaveUsers(const string& filename, const unordered_map<string, string>& users) {
    ofstream file(filename, ios::trunc);
    if (!file.is_open()) {
        cerr << "Impossible d'écrire dans le fichier utilisateurs" << endl;
        return;
    }

    for (const auto& [id, token] : users) {
        file << id << " " << token << "\n";
    }
}

UniqueSSLCTX InitServerCTX(const string& certFile, const string& keyFile) {
    UniqueSSLCTX ctx(SSL_CTX_new(TLS_server_method()));
    if (!ctx) {
        ERR_print_errors_fp(stderr);
        return nullptr;
    }

    if (SSL_CTX_use_certificate_file(ctx.get(), certFile.c_str(), SSL_FILETYPE_PEM) <= 0 ||
        SSL_CTX_use_PrivateKey_file(ctx.get(), keyFile.c_str(), SSL_FILETYPE_PEM) <= 0) {
        ERR_print_errors_fp(stderr);
        return nullptr;
    }

    // Désactiver la vérification du certificat SSL (ne pas valider le certificat)
    SSL_CTX_set_verify(ctx.get(), SSL_VERIFY_NONE, nullptr);

    return ctx;
}

UniqueSSL AcceptSSLConnection(SSL_CTX* ctx, int clientSocket) {
    UniqueSSL ssl(SSL_new(ctx));
    if (!ssl) {
        ERR_print_errors_fp(stderr);
        close(clientSocket);
        return nullptr;
    }

    SSL_set_fd(ssl.get(), clientSocket);
    if (SSL_accept(ssl.get()) <= 0) {
        ERR_print_errors_fp(stderr);
        close(clientSocket);
        return nullptr;
    }

    return ssl;
}

void Server::serverLoop() {
    std::cout << "Serveur sur écoute..." << std::endl;

    while (true) {
        {
            // Utilisation de la fonction d'accès au mutex et à la valeur
            std::lock_guard<std::mutex> lock(Globals::getSRDMutex());
            std::cout << "[SRD-BTC] Valeur actuelle : " << Globals::getLastSRDBTCValue() << " USD" << std::endl;
        }

        std::this_thread::sleep_for(std::chrono::seconds(2));
    }
}

void Server::HandleClient(UniqueSSL ssl, unordered_map<string, string>& users, mutex& usersMutex,
                         const string& usersFile, const string& logFile) {
    std::cout << "Client connecté, tentative de handshake SSL..." << std::endl;
       
    if (SSL_accept(ssl.get()) <= 0) {
       std::cerr << "Échec du handshake SSL" << std::endl;
        ERR_print_errors_fp(stderr);
       return;
    }
       
   std::cout << "✅ Handshake SSL réussi !" << std::endl;

    char buffer[1024] = {0};
    int bytes = SSL_read(ssl.get(), buffer, sizeof(buffer) - 1);
    if (bytes <= 0) {
        ERR_print_errors_fp(stderr);
        return;
    }

    buffer[bytes] = '\0';
    string receivedMessage(buffer);
    cout << "Reçu: " << receivedMessage << endl;

    string response;
    string id, token;
    string prefix_id = "ID:";
    string prefix_token = "TOKEN:";

    if (receivedMessage.find(prefix_id) != string::npos && 
        receivedMessage.find(prefix_token) != string::npos) {
        size_t id_start = receivedMessage.find(prefix_id) + prefix_id.length();
        size_t id_end = receivedMessage.find(",", id_start);
        id = receivedMessage.substr(id_start, id_end - id_start);

        size_t token_start = receivedMessage.find(prefix_token) + prefix_token.length();
        token = receivedMessage.substr(token_start);

        cout << "ID extrait: " << id << ", Token: " << token << endl;

        {
            lock_guard<mutex> lock(usersMutex);
            auto it = users.find(id);
            if (it != users.end() && it->second == token) {
                response = "AUTH OK";
            } else {
                response = "AUTH FAIL";
            }
        }
    } else {
        id = GenerateRandomId();
        token = GenerateToken();
        {
            lock_guard<mutex> lock(usersMutex);
            users[id] = token;
            SaveUsers(usersFile, users);
        }

    // Créer un fichier portefeuille vierge dans le cas d'un nouveau client

    ofstream walletFile("../src/data/wallets/" + id + ".wallet");
    walletFile << "DOLLARS:10000\n";
    walletFile << "SRD-BTC:0\n";
    walletFile.close();

    cout << "Nouvel ID: " << id << ", Nouveau Token: " << token << endl;
    response = "Identifiants: " + id + " " + token;
    }

    if (SSL_write(ssl.get(), response.c_str(), response.size()) <= 0) {
        cerr << "Erreur lors de l'envoi de la réponse au client" << endl;
        ERR_print_errors_fp(stderr);
    }

    auto bot = make_shared<Bot>("SRD-BTC", id);
    thread([bot]() {
        while (true) {
            bot->trading("SRD-BTC");
            this_thread::sleep_for(chrono::seconds(1));
        }
    }).detach();

    while (true) {
        char buffer2[1024] = {0};
        int bytes2 = SSL_read(ssl.get(), buffer2, sizeof(buffer2) - 1);
        if (bytes2 <= 0) {
            ERR_print_errors_fp(stderr);
            break;
        }

        buffer2[bytes2] = '\0';
        string nextRequest(buffer2);
        cout << "Requête suivante reçue: " << nextRequest << endl;
        ProcessRequest(ssl.get(), logFile, nextRequest, id);
    }
}

void Server::StartServer(int port, const string& certFile, const string& keyFile,
    const string& usersFile, const string& logFile) {

    if (!filesystem::exists(certFile) || !filesystem::exists(keyFile)) {
        cerr << "Certificat ou clé SSL introuvable." << endl;
        return;
    }

    auto ctx = InitServerCTX(certFile, keyFile);
    if (!ctx) return;

    int serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == -1) {
        perror("socket failed");
        return;
    }

    int opt = 1;
    setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    sockaddr_in serverAddr{};
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(port);

    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("bind failed");
        close(serverSocket);
        return;
    }

    if (listen(serverSocket, 5) < 0) {
        perror("listen failed");
        close(serverSocket);
        return;
    }

    cout << "Serveur démarré sur le port " << port << endl;

    thread([this]() {
        Global::generate_SRD_BTC_loop(); // Appel de la boucle qui génère les valeurs SRD-BTC
    }).detach();

    // Lancer la boucle de mise à jour et d'affichage des valeurs BTC dans un thread séparé
    thread([this]() {
        serverLoop(); // Appel de la boucle serveur
    }).detach();

    // Chargement des utilisateurs et création du mutex
    auto users = LoadUsers(usersFile);
    std::mutex usersMutex;

    while (true) {
        sockaddr_in clientAddr{};
        socklen_t clientLen = sizeof(clientAddr);
        int clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &clientLen);

        if (clientSocket < 0) {
            perror("accept failed");
            continue;
        }

        auto ssl = AcceptSSLConnection(ctx.get(), clientSocket);
        if (!ssl) {
            continue;
        }

        // ✅ Thread détaché pour gérer ce client de façon indépendante
        thread([this, ssl = std::move(ssl), &users, &usersMutex, &usersFile, &logFile, clientSocket]() mutable {
            HandleClient(std::move(ssl), users, usersMutex, usersFile, logFile);

            int shutdownRet = SSL_shutdown(ssl.get());
            if (shutdownRet == 0) {
                // Nécessite un second appel
                shutdownRet = SSL_shutdown(ssl.get());
            }

            if (shutdownRet != 1) {
                cerr << "Erreur lors de la fermeture de la connexion SSL" << endl;
                ERR_print_errors_fp(stderr);
            } else {
                cout << "Connexion SSL fermée proprement" << endl;
            }

            close(clientSocket); // Très important !
        }).detach();
    }

    close(serverSocket);
}

void Server::ProcessRequest(ssl_st* ssl, const std::string& logFile, const std::string& request, const std::string& id) {
    std::string response;

    // Traitement de la requête du client
    std::cout << "Traitement de la requête: " << request << std::endl;

    if (request.find("SHOW TRANSACTION HISTORY") != std::string::npos) {
        std::ifstream file("../src/data/TransactionHistory.log");
        if (file.is_open()) {
            std::stringstream ss;
            std::string line;
            while (std::getline(file, line)) {
                if (line.find("Client ID: " + id) != std::string::npos) {
                    ss << line << "\n";
                }
            }
            response = ss.str();
            if (response.empty()) {
                response = "Aucune transaction trouvée.";
            }
        } else {
            response = "Erreur lors de l'ouverture de l'historique.";
        }
    } else if (request == "SHOW WALLET") {
        auto bot = std::make_shared<Bot>("SRD-BTC", id);

        double dollars = bot->getBalance("DOLLARS");
        double crypto = bot->getBalance("SRD-BTC");

        std::stringstream ss;
        ss << "Portefeuille de " << id << ":\n";
        ss << "💵 DOLLARS: " << dollars << "\n";
        ss << "🪙 SRD-BTC: " << crypto << "\n";

        response = ss.str();
    } else {
        response = "Requête inconnue.";
    }

    // Envoi de la réponse
    if (SSL_write(ssl, response.c_str(), response.size()) <= 0) {
        std::cerr << "Erreur lors de l'envoi de la réponse." << std::endl;
        ERR_print_errors_fp(stderr);
    }
}