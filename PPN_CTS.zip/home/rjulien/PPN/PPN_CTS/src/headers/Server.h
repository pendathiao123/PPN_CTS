#ifndef SERVER_H
#define SERVER_H

#include <openssl/ssl.h>
#include <openssl/err.h>
#include <unordered_map>
#include <string>
#include <memory>
#include <mutex>


// Forward declarations pour les deleters personnalisés
struct SSLDeleter {
    void operator()(SSL* ssl) const;
};

struct SSLCTXDeleter {
    void operator()(SSL_CTX* ctx) const;
};

// Aliases RAII pour SSL
using UniqueSSL = std::unique_ptr<SSL, SSLDeleter>;
using UniqueSSLCTX = std::unique_ptr<SSL_CTX, SSLCTXDeleter>;

// Fonctions utilitaires
std::string GenerateRandomString(size_t length);
std::string GenerateRandomId();
std::string GenerateToken();
std::unordered_map<std::string, std::string> LoadUsers(const std::string& filename);
void SaveUsers(const std::string& filename, const std::unordered_map<std::string, std::string>& users);

// Fonctions SSL RAII
UniqueSSLCTX InitServerCTX(const std::string& certFile, const std::string& keyFile);
UniqueSSL AcceptSSLConnection(SSL_CTX* ctx, int clientSocket);

class Server {
public:
    void StartServer(int port,
                     const std::string& certFile,
                     const std::string& keyFile,
                     const std::string& usersFile,
                     const std::string& logFile);

private:
    void HandleClient(UniqueSSL ssl,
                      std::unordered_map<std::string, std::string>& users,
                      std::mutex& usersMutex,
                      const std::string& usersFile,
                      const std::string& logFile);

    void ProcessRequest(SSL* ssl,
                        const std::string& logFile,
                        const std::string& request,
                        const std::string& clientId);

    // Fonction qui va lire la variable tampon contenant la dernière valeur SRD-BTC en date (générée dans Global.cpp)
    void serverLoop();
};

#endif // SERVER_H