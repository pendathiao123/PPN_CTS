#ifndef BOT_H
#define BOT_H

#include <string>
#include <unordered_map>
#include <memory>
#include "../headers/Client.h"
#include "../headers/Global.h"

class Bot {

public:

    Bot(const std::string &currency, const std::string &clientId);
    ~Bot();

    void trading(const std::string &currency);
    void buyCrypto(const std::string &currency, double pourcentage);
    void sellCrypto(const std::string &currency, double pourcentage);
    void updateBalance();
    std::unordered_map<std::string, double> get_total_Balance();
    double getBalance(const std::string &currency);
    void saveBalance();  // Méthode pour enregistrer les soldes dans le fichier wallet
    void logTransaction(const std::string& action, const std::string& currency, double percentage, double amount, double price);

private:
    std::shared_ptr<Client> client;
    std::shared_ptr<Global> global;
    std::string id;  // L'ID du client pour gérer son portefeuille spécifique
    std::unordered_map<std::string, double> balance;  // Maintien des soldes en mémoire
    double solde_origin;
    double prv_price;

    // Méthodes pour charger et sauvegarder le portefeuille
    void loadWallet();
    void saveWallet();
};

#endif // BOT_H
