#ifndef GLOBAL_H
#define GLOBAL_H

#include <atomic>
#include <array>
#include <string>
#include <mutex>

namespace Globals {
    // Mutex pour synchroniser l'accès à la valeur SRD-BTC
    extern std::mutex srdMutex;
    // Dernière valeur SRD-BTC générée (tampon partagé entre threads)
    extern double lastSRDBTCValue;

    // Accesseurs thread-safe
    std::mutex& getSRDMutex();
    double getLastSRDBTCValue();
    void setLastSRDBTCValue(double value);
}

class Global {
private:
    static std::atomic<bool> stopRequested;

public:
    // Accesseur pour arrêt des threads
    static std::atomic<bool>& getStopRequested();

    // Autres méthodes
    static double getRandomDouble();
    static void recordBTCValuesToCSV(const std::string& filename, int durationSeconds);
    static void generate_SRD_BTC_loop();

    // Lecture de prix (non-statiques)
    double getPrice(const std::string& currency);
    double getPreviousPrice(const std::string& currency, int secondsBack);
};

#endif // GLOBAL_H
